import UIKit

//First Task
var x = 3

var t = Int(sqrt(Double(x))) + (20 * x / 8)
print("equalization = \(t)")

//Second Task
var a = 6
var b = 5
var c = 4
var P = Int()

P = a + b
c = Int(sqrt(pow(Double(a), 2) + pow(Double(b), 2)))
P = P + c

print("Hypotenuse = \(c), " + "Perimeter = \(P)")

//Third Task
func thirdTask(summOfDeposite: Int, percentagePerYear: Int) {
    var overallAfter5Years = 0
    for i in 1...5 {
        
        overallAfter5Years = summOfDeposite * percentagePerYear * ((i * 365) / 365) / 100
        print("\(i) year \(overallAfter5Years)")
    }
    
}

thirdTask(summOfDeposite: 50000, percentagePerYear: 12)

